﻿using System;
using System.Collections.Generic;
using Microsoft.AspNet.Mvc;
using MPTWebApi5GetStarted.Service.Models;
using MPTWebApi5GetStarted.Service.ResultCode;
using Swashbuckle.SwaggerGen.Annotations;

namespace MPTWebApi5GetStarted.Service.Controllers
{
    /// <summary>
    /// Kontroller for å håndtere MPT ordre
    /// </summary>
    [Route("api/order/")]
    public class OrderController : Controller
    {
        /// <summary>
        /// Returnerer alle åpne ordre på angitt dato
        /// </summary>
        /// <param name="dob">Pasientens fødselsdato</param>
        /// <param name="ssn">Pasientens personnummer</param>
        /// <param name="fromDate">Metoden skal returnere åpne ordre tilbake til denne datoen (yyyy-MM-dd)</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>Order-resultat med resultatkoder og order-array hvis funnet (returkode = 0)</returns>
        [HttpGet]
        [Route("[action]")]
        [ActionName("GetOrderDOB")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(OrderResult))]
        public IActionResult GetOrderDOB([FromQuery]string dob, [FromQuery]string ssn, [FromQuery]DateTime fromDate, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new OrderResult();
            var orders = new List<Order>();

            // TODO: Implement data extraction from your Journal System
            //foreach (var item in collection)
            //{
            var order = new Order();

            // TODO: Map to order

            orders.Add(order);
            //}

            result.OrderArray = orders.ToArray();

            return new ObjectResult(result);
        }

        /// <summary>
        /// Returnerer alle åpne ordre hvor patientsum > 0, og ordredato mellom dagens dato og dato angitt i date-parameteret.
        /// </summary>
        /// <param name="date">Metoden skal returnere ordre tilbake til og med denne datoen datoen (yyyy-MM-dd)</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>Order-resultat med resultatkoder og order-array hvis funnet (returkode = 0)</returns>
        [HttpGet]
        [Route("[action]")]
        [ActionName("GetOpenOrders")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(OrderResult))]
        public IActionResult GetOpenOrders([FromQuery]DateTime date, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new OrderResult();
            var orders = new List<Order>();

            // TODO: Implement data extraction from your Journal System
            //foreach (var item in collection)
            //{
            var order = new Order();

            // TODO: Map to order

            orders.Add(order);
            //}

            result.OrderArray = orders.ToArray();

            return new ObjectResult(result);
        }

        /// <summary>
        /// Returnerer alle fakturaer med utestående sum tilbake til og med datoen spesifisert i date-parameteret. 
        /// Dette kallet brukes i de tilfeller man ikke kan opprette en ordre på flere avtaler eller endre fakturamottaker og liknende uten å fakturere ordren.
        /// </summary>
        /// <param name="date">Metoden skal returnere ordre tilbake til og med denne datoen datoen (yyyy-MM-dd)</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>Order-resultat med resultatkoder og order-array hvis funnet (returkode = 0)</returns>
        [HttpGet]
        [Route("[action]")]
        [ActionName("GetOpenInvoices")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(OrderResult))]
        public IActionResult GetOpenInvoices([FromQuery]DateTime date, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new OrderResult();
            var orders = new List<Order>();

            // TODO: Implement data extraction from your Journal System
            //foreach (var item in collection)
            //{
            var order = new Order();

            // TODO: Map to order

            orders.Add(order);
            //}

            result.OrderArray = orders.ToArray();

            return new ObjectResult(result);
        }

        /// <summary>
        /// Metoden returnerer alle fakturerte ordre som har blitt krediterte/nullstilte/slettet på den spesifiserte datoen i date-parameteret.
        /// </summary>
        /// <param name="date">Ordre med denne krediteringsdatoen skal returneres (yyyy-MM-dd)</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>Order-resultat med resultatkoder og order-array hvis funnet (returkode = 0)</returns>
        [HttpGet]
        [Route("[action]")]
        [ActionName("GetCreditedOrders")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(OrderResult))]
        public IActionResult GetCreditedOrders([FromQuery]DateTime date, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new OrderResult();
            var orders = new List<Order>();

            // TODO: Implement data extraction from your Journal System
            //foreach (var item in collection)
            //{
            var order = new Order();

            // TODO: Map to order

            orders.Add(order);
            //}

            result.OrderArray = orders.ToArray();

            return new ObjectResult(result);
        }

        /// <summary>
        /// Metoden kalles for å lukke en ordre som betalt eller fakturert. 
        /// Ordre som er lukket med payMethod 8 skal ikke lenger returneres av GetOpenOrders eller GetOpenInvoices. 
        /// Kun fakturaer lukket med payMethod = 8 kan lukkes med payMethod 3. 
        /// Kun åpne ordre skal kunne lukkes med payMethod 1 og 2. 
        /// CloseOrder skal ikke tillate å betale samme ordre/faktura flere ganger.
        /// </summary>
        /// <param name="orderNumber">Ordrenummer som skal lukkes</param>
        /// <param name="payMethod">Betalingsmetode: 1 = Betalt med kort. 2 = betalt med kontant. 3 = betalt med faktura. 8 = faktura generert</param>
        /// <param name="sum">Beløp betalt</param>
        /// <param name="cardType">Korttypen som regningen ble betalt med. Denne vil kun være med om payMethod = 1. Ellers 0.</param>
        /// <param name="ledgerId">Regnskapet regningen tilhører</param>
        /// <param name="paymentDate">Datoen betalingen ble registrert (yyyy-MM-ddTHH:mm:ss)</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>SingleResult med resultatkoder</returns>
        [HttpPut]
        [Route("[action]")]
        [ActionName("CloseOrder")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(SingleResult))]
        public IActionResult CloseOrder([FromQuery]string orderNumber, [FromQuery]int payMethod, [FromQuery]decimal sum, [FromQuery]int cardType, [FromQuery]DateTime paymentDate, [FromQuery]string ledgerId, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new SingleResult();
            // TODO: Implement CloseOrder on your Journal System

            return new ObjectResult(result);
        }

        /// <summary>
        /// Metoden brukes for å låse en ordre slik at ingen andre brukere kan endre på ordren innen den låses opp igjen. 
        /// Låsen må tidsavbrytes etter en kort periode, anbefalt 5 minutter. 
        /// Parameteret terminlaId brukes for autentisering ved LockOrder og UnLockOrder. 
        /// Om en bruker forsøker å endre en låst ordre anbefales det at EPJ informerer brukeren om hvilken terminalId som har låst ordren.
        /// </summary>
        /// <param name="orderNumber">Ordrenummer som skal låses</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>SingleResult med resultatkoder</returns>
        [HttpPut]
        [Route("[action]")]
        [ActionName("LockOrder")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(SingleResult))]
        public IActionResult LockOrder([FromQuery]string orderNumber, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new SingleResult();
            // TODO: Implement LockOrder on your Journal System

            return new ObjectResult(result);
        }

        /// <summary>
        /// Metoden brukes for å låse opp en ordre etter ordren er ferdig behandlet. 
        /// Parameteret terminlaId brukes for autentisering ved LockOrder og UnLockOrder.
        /// </summary>
        /// <param name="orderNumber">Ordrenummer som skal låses opp</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>SingleResult med resultatkoder</returns>
        [HttpPut]
        [Route("[action]")]
        [ActionName("UnLockOrder")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(SingleResult))]
        public IActionResult UnLockOrder([FromQuery]string orderNumber, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new SingleResult();
            // TODO: Implement UnLockOrder on your Journal System

            return new ObjectResult(result);
        }
    }
}
