﻿using System.Collections.Generic;
using Microsoft.AspNet.Mvc;
using MPTWebApi5GetStarted.Service.Models;
using MPTWebApi5GetStarted.Service.ResultCode;
using Swashbuckle.SwaggerGen.Annotations;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace MPTWebApi5GetStarted.Service.Controllers
{
    /// <summary>
    /// Kontroller for å håndtere MPT brukere
    /// </summary>
    [Route("api/user/")]
    public class UserController : Controller
    {
        /// <summary>
        /// Returnerer opplysninger på brukeren Signature-parameteret tilhører og regnskapet ledgerId er tilknyttet. 
        /// Signature må være unikt for klinikk eller regnskap, slik at kallet kun returnerer et resultat på behandler og regnskap. 
        /// Signature og ledgerID som oppgis er de verdiene med samme navn som er hentet med GetOrderDOB, GetOpenOrders og/eller GetOpenInvoices.
        /// </summary>
        /// <param name="initials">Behandlerens unike signatur i EPJ</param>
        /// <param name="ledgerId">Regnskaps-ID</param>
        /// <param name="terminalId">Terminalens ID</param>
        /// <param name="authKey">En nøkkel på minimum 20 karakterer bestående av tall og store og små bokstaver</param>
        /// <returns>UserInfo-resultat med resultatkoder og userinfo-array hvis funnet (returkode = 0)</returns>
        [HttpGet]
        [Route("[action]")]
        [ActionName("GetUserInfo")]
        [SwaggerResponse(System.Net.HttpStatusCode.OK, Type = typeof(UserInfoResult))]
        public IActionResult GetUserInfo([FromQuery]string initials, [FromQuery]string ledgerId, [FromQuery]string terminalId, [FromQuery]string authKey)
        {
            var result = new UserInfoResult();
            var users = new List<UserInfo>();

            // TODO: Implement data extraction from your Journal System
            //foreach (var item in collection)
            //{
            var user = new UserInfo();

            // TODO: Map to user

            users.Add(user);
            //}

            result.UserInfoArray = users.ToArray();

            return new ObjectResult(result);
        }
    }
}
