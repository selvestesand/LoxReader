﻿using MPTWebApi5GetStarted.Service.Common;
using MPTWebApi5GetStarted.Service.Models;

namespace MPTWebApi5GetStarted.Service.ResultCode
{
    public class OrderResult
    {
        public int ResultCode { get; set; }

        public string Description { get; set; }

        public Order[] OrderArray { get; set; }

        public OrderResult()
        {
            ResultCode = CommonTypes.Success;
            Description = string.Empty;
            OrderArray = new Order[0];
        }
    }
}
