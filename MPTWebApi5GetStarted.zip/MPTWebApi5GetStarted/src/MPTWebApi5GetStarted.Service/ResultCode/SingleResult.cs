﻿using MPTWebApi5GetStarted.Service.Common;

namespace MPTWebApi5GetStarted.Service.ResultCode
{
    public class SingleResult
    {
        public int ResultCode { get; set; }

        public string Description { get; set; }

        public SingleResult()
        {
            ResultCode = CommonTypes.Success;
            Description = string.Empty;
        }
    }
}
