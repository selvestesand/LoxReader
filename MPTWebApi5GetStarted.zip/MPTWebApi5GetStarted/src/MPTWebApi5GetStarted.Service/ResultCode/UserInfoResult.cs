﻿using MPTWebApi5GetStarted.Service.Common;
using MPTWebApi5GetStarted.Service.Models;

namespace MPTWebApi5GetStarted.Service.ResultCode
{
    public class UserInfoResult
    {
        public int ResultCode { get; set; }

        public string Description { get; set; }

        public UserInfo[] UserInfoArray { get; set; }

        public UserInfoResult()
        {
            ResultCode = CommonTypes.Success;
            Description = string.Empty;
            UserInfoArray = new UserInfo[0];
        }
    }
}
