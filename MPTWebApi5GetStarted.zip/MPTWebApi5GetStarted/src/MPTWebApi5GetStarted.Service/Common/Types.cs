﻿using System.ComponentModel;

namespace MPTWebApi5GetStarted.Service.Common
{
    public static class CommonTypes
    {
        public const int Success = 0;
        public const int UnknownError = 99;
    }

    public enum GenderEnum
    {
        U = 0,
        M = 1,
        F = 2
    }

    public enum DeliveryMethod
    {
        None = 0,
        Sms = 1,
        Email = 2,
        SmsAndEmail = 3
    }
}
