﻿using System;
using MPTWebApi5GetStarted.Service.Common;
using MPTWebApi5GetStarted.Service.Helper;

namespace MPTWebApi5GetStarted.Service.Models
{
    public class OrderDetails
    {
        public string HealthCareType { get; set; }

        public string OrderNumber { get; set; }

        public DateTime OrderDate { get; set; }

        public string OrderComment { get; set; }

        public string Signature { get; set; }

        public string LedgerID { get; set; }

        public int NumberOfCouncellors { get; set; }

        public DateTime ReferenceDate { get; set; }

        public decimal ExpectedGrant { get; set; }

        public DateTime DueDate { get; set; }

        public string Generic1 { get; set; }

        public string Generic2 { get; set; }

        public string Generic3 { get; set; }

        public string Generic4 { get; set; }

        public string Generic5 { get; set; }

        public string Generic6 { get; set; }

        public string Generic7 { get; set; }

        public string Generic8 { get; set; }

        public string Generic9 { get; set; }

        public string Generic10 { get; set; }

        public DeliveryMethod UnwantedDeliveryMethod { get; set; }

        public OrderLine[] OrderLines { get; set; }

        public OrderDetails()
        {
            HealthCareType = string.Empty;
            OrderNumber = string.Empty;
            OrderDate = new DateTime(1900, 1, 1);
            OrderComment = string.Empty;
            Signature = string.Empty;
            LedgerID = string.Empty;
            NumberOfCouncellors = 1;
            ReferenceDate = new DateTime(1900, 1, 1);
            ExpectedGrant = 0;
            DueDate = new DateTime(1900, 1, 1);
            Generic1 = string.Empty;
            Generic2 = string.Empty;
            Generic3 = string.Empty;
            Generic4 = string.Empty;
            Generic5 = string.Empty;
            Generic6 = string.Empty;
            Generic7 = string.Empty;
            Generic8 = string.Empty;
            Generic9 = string.Empty;
            Generic10 = string.Empty;
            UnwantedDeliveryMethod = DeliveryMethod.None;
            OrderLines = new OrderLine[1].Populate(() => new OrderLine());
        }
    }
}
