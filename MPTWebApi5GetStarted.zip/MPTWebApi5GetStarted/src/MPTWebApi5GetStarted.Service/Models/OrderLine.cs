﻿using System;

namespace MPTWebApi5GetStarted.Service.Models
{
    public class OrderLine
    {
        public ProductType ProductType { get; set; }

        public string ProductName { get; set; }

        public string Description { get; set; }

        public DateTime Date { get; set; }

        public string User { get; set; }

        public decimal Sum { get; set; }

        public decimal Patientsum { get; set; }

        public decimal PublicHealthCareSum { get; set; }

        public decimal GrantSum { get; set; }

        public decimal VATPercent { get; set; }

        public decimal VATSum { get; set; }

        public int Quantity { get; set; }

        public OrderLine()
        {
            ProductType = ProductType.Undefined;
            ProductName = string.Empty;
            Description = string.Empty;
            Date = new DateTime(1900, 1, 1);
            User = string.Empty;
            Sum = 0;
            Patientsum = 0;
            PublicHealthCareSum = 0;
            GrantSum = 0;
            VATPercent = 0;
            VATSum = 0;
            Quantity = 0;
        }
    }
}
