﻿namespace MPTWebApi5GetStarted.Service.Models
{
    public class Address
    {
        public string StreetAddress { get; set; }

        public string PostalCode { get; set; }

        public string City { get; set; }

        public string CountryCode { get; set; }

        public Address()
        {
            StreetAddress = string.Empty;
            PostalCode = string.Empty;
            City = string.Empty;
            CountryCode = string.Empty;
        }
    }
}
