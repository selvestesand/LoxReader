﻿using System;
using MPTWebApi5GetStarted.Service.Common;

namespace MPTWebApi5GetStarted.Service.Models
{
    public class UserInfo
    {
        public string GivenName { get; set; }

        public string FamilyName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string SSN { get; set; }

        public GenderEnum Gender { get; set; }

        public string Signature { get; set; }

        public string UserID { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Mobile { get; set; }

        public Address Address { get; set; }

        public MainLedger MainLedger { get; set; }

        public UserInfo()
        {
            GivenName = string.Empty;
            FamilyName = string.Empty;
            DateOfBirth = new DateTime(1900, 1, 1);
            SSN = string.Empty;
            Gender = GenderEnum.U;
            Signature = string.Empty;
            UserID = string.Empty;
            Email = string.Empty;
            Phone = string.Empty;
            Mobile = string.Empty;
            Address = new Address();
            MainLedger = new MainLedger();
        }
    }
}
