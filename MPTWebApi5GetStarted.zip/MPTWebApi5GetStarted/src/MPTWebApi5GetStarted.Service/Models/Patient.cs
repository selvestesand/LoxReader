﻿using System;
using MPTWebApi5GetStarted.Service.Common;

namespace MPTWebApi5GetStarted.Service.Models
{
    public class Patient
    {
        public string FamilyName { get; set; }

        public string GivenName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string SSN { get; set; }

        public GenderEnum Gender { get; set; }

        public string Phone { get; set; }

        public string Mobile { get; set; }

        public string Email { get; set; }

        public Address Address { get; set; }

        public InvoiceAddress InvoiceAddress { get; set; }

        public Patient()
        {
            FamilyName = string.Empty;
            GivenName = string.Empty;
            DateOfBirth = new DateTime(1900, 1, 1);
            SSN = string.Empty;
            Gender = GenderEnum.U;
            Phone = string.Empty;
            Mobile = string.Empty;
            Email = string.Empty;
            Address = new Address();
            InvoiceAddress = new InvoiceAddress();
        }
    }
}
