﻿namespace MPTWebApi5GetStarted.Service.Models
{
    public class Order
    {
        public Patient Patient { get; set; }

        public OrderDetails OrderDetails { get; set; }

        public Order()
        {
            Patient = new Patient();
            OrderDetails = new OrderDetails();
        }
    }
}
