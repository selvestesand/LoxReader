﻿namespace MPTWebApi5GetStarted.Service.Models
{
    public class MainLedger
    {
        public string LedgerId { get; set; }

        public string Name { get; set; }

        public string AccountNumber { get; set; }

        public string OrganizationName { get; set; }

        public string OrganizationNumber { get; set; }

        public string AccountRegistrationNumber { get; set; }

        public MainLedger()
        {
            LedgerId = string.Empty;
            Name = string.Empty;
            AccountNumber = string.Empty;
            OrganizationName = string.Empty;
            OrganizationNumber = string.Empty;
            AccountRegistrationNumber = string.Empty;
        }
    }
}
