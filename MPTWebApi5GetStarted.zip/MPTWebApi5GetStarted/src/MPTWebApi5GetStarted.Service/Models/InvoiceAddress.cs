﻿namespace MPTWebApi5GetStarted.Service.Models
{
    public class InvoiceAddress : Address
    {
        public string InvoiceRecipient { get; set; }

        public string OrganizationNumber { get; set; }

        public InvoiceAddress()
        {
            InvoiceRecipient = string.Empty;
            OrganizationNumber = string.Empty;
        }
    }
}
