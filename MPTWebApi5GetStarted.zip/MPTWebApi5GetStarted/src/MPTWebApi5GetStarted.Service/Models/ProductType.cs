﻿namespace MPTWebApi5GetStarted.Service.Models
{
    public enum ProductType
    {
        Undefined = 0,
        HelfoDeductible = 1,
        Deductible = 2,
        Merchandise = 3,
        Discount = 4,
        Subscription = 5,
        PrepaidAmount = 6
    }
}
