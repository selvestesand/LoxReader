﻿using System;

namespace MPTWebApi5GetStarted.Service.Helper
{
    /// <summary>
    /// Init Helper
    /// </summary>
    public static class PopulateHelper
    {
        public static T[] Populate<T>(this T[] array, Func<T> provider)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = provider();
            }

            return array;
        }
    }
}
